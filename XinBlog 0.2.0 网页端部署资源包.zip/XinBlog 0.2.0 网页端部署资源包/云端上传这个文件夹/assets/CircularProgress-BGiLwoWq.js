import{$ as e,E as t,F as n,I as r,P as i,d as a,et as o,f as s,g as c,h as l,r as u,st as d,tt as f,ut as p}from"./Fade-DLb3qQ0D.js";var m=p(d());function h(e){return n(`MuiCircularProgress`,e)}i(`MuiCircularProgress`,[`root`,`determinate`,`indeterminate`,`colorPrimary`,`colorSecondary`,`svg`,`circle`,`circleDeterminate`,`circleIndeterminate`,`circleDisableShrink`]);var g=e(),_=44,v=f`
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
`,y=f`
  0% {
    stroke-dasharray: 1px, 200px;
    stroke-dashoffset: 0;
  }

  50% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -15px;
  }

  100% {
    stroke-dasharray: 1px, 200px;
    stroke-dashoffset: -126px;
  }
`,b=typeof v==`string`?null:o`
        animation: ${v} 1.4s linear infinite;
      `,x=typeof y==`string`?null:o`
        animation: ${y} 1.4s ease-in-out infinite;
      `,S=e=>{let{classes:n,variant:r,color:i,disableShrink:a}=e;return t({root:[`root`,r,`color${l(i)}`],svg:[`svg`],circle:[`circle`,`circle${l(r)}`,a&&`circleDisableShrink`]},h,n)},C=c(`span`,{name:`MuiCircularProgress`,slot:`Root`,overridesResolver:(e,t)=>{let{ownerState:n}=e;return[t.root,t[n.variant],t[`color${l(n.color)}`]]}})(s(({theme:e})=>({display:`inline-block`,variants:[{props:{variant:`determinate`},style:{transition:e.transitions.create(`transform`)}},{props:{variant:`indeterminate`},style:b||{animation:`${v} 1.4s linear infinite`}},...Object.entries(e.palette).filter(u()).map(([t])=>({props:{color:t},style:{color:(e.vars||e).palette[t].main}}))]}))),w=c(`svg`,{name:`MuiCircularProgress`,slot:`Svg`,overridesResolver:(e,t)=>t.svg})({display:`block`}),T=c(`circle`,{name:`MuiCircularProgress`,slot:`Circle`,overridesResolver:(e,t)=>{let{ownerState:n}=e;return[t.circle,t[`circle${l(n.variant)}`],n.disableShrink&&t.circleDisableShrink]}})(s(({theme:e})=>({stroke:`currentColor`,variants:[{props:{variant:`determinate`},style:{transition:e.transitions.create(`stroke-dashoffset`)}},{props:{variant:`indeterminate`},style:{strokeDasharray:`80px, 200px`,strokeDashoffset:0}},{props:({ownerState:e})=>e.variant===`indeterminate`&&!e.disableShrink,style:x||{animation:`${y} 1.4s ease-in-out infinite`}}]}))),E=m.forwardRef(function(e,t){let n=a({props:e,name:`MuiCircularProgress`}),{className:i,color:o=`primary`,disableShrink:s=!1,size:c=40,style:l,thickness:u=3.6,value:d=0,variant:f=`indeterminate`,...p}=n,m={...n,color:o,disableShrink:s,size:c,thickness:u,value:d,variant:f},h=S(m),v={},y={},b={};if(f===`determinate`){let e=2*Math.PI*((_-u)/2);v.strokeDasharray=e.toFixed(3),b[`aria-valuenow`]=Math.round(d),v.strokeDashoffset=`${((100-d)/100*e).toFixed(3)}px`,y.transform=`rotate(-90deg)`}return(0,g.jsx)(C,{className:r(h.root,i),style:{width:c,height:c,...y,...l},ownerState:m,ref:t,role:`progressbar`,...b,...p,children:(0,g.jsx)(w,{className:h.svg,ownerState:m,viewBox:`${_/2} ${_/2} ${_} ${_}`,children:(0,g.jsx)(T,{className:h.circle,style:v,ownerState:m,cx:_,cy:_,r:(_-u)/2,fill:`none`,strokeWidth:u})})})});export{E as t};